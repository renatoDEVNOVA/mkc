<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
    <title>Solicitud de unión a equipo </title>
</head>
<body>
    <p><?php echo e($name); ?> , ha solicitado unirse a tu equipo en ADP</p>
    <br>
    <button>
        <a href="http://127.0.0.1:5500/dashboard.html?id=<?php echo e($id); ?>">
            Invita a tu organización
        </a>
    </button>
    <p>AGENTE DE PRENSA</p>
</body>
</html><?php /**PATH C:\laragon\www\saas\resources\views/emails/request-join.blade.php ENDPATH**/ ?>