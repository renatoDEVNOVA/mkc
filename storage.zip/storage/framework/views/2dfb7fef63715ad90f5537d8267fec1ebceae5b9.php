<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REPORTE DETALLADO POR CAMPAÑAS</title>
    <style>

        * {
            margin: 0;
            padding: 0;
        }

        @font-face {
            font-family : 'Poppins';
            src: url('<?php echo e(storage_path("fonts/Poppins-Regular.ttf")); ?>');
        }

        @font-face {
            font-family : 'Poppins';
            src: url('<?php echo e(storage_path("fonts/Poppins-Bold.ttf")); ?>');
            font-weight: bold;
        }

        body {
            margin: 150px 50px 50px 50px;
            font-family: 'Poppins', Courier, Helvetica, sans-serif;
            font-size: 13px;
            color: #454545;
        }

        /* header */

        header {
            /*text-align: center;*/
            position: fixed;
            /*left: 0;
            top: 0;
            right: 0;*/
        }

        header .header_adp {
            margin: 50px 50px 20px 50px;
            /*overflow: auto;*/
        }

        header .header_adp .logo,
        header .header_adp .title {
            width: 50%;
            display: inline-block;
        }

        header .header_adp .logo {
            text-align: right;
        }

        header .header_adp .title {
            text-align: left;
        }

        header .header_cliente {
            margin: 20px 50px;
            overflow: auto;
        }

        header .header_cliente .client {
            text-align: left;
            /*width: 200px;
            display: inline-block;*/
        }

        .content table {
            width: 100%;
        }

        .content .first-page table thead {
            background-color: #FF3333;
            color: #fff;
        }

        .content .first-page table,
        .content .first-page th,
        .content .first-page td {
            border: 1px solid #FFFFFF;
            border-collapse: collapse;
        }

        .content .first-page th,
        .content .first-page td {
            padding: 5px;
        }

        .content .first-page .container-table {
            margin-bottom: 20px;
        }

        .content .first-page .statistics-table tbody tr:nth-child(even){
            background-color: #F9F9F9;
        }

        .content .first-page .statistics-table tbody tr:nth-child(odd){
            background-color: #FDFDFD;
        }

        .content .second-page table thead {
            background-color: #FFFFFF;
            color: #454545;
        }

        .content .second-page table,
        .content .second-page th,
        .content .second-page td {
            border-bottom: 1px solid #C4C4C4;
            border-collapse: collapse;
        }

        .content .second-page th,
        .content .second-page td {
            padding: 5px;
        }

        .content .second-page .container-table {
            margin-bottom: 20px;
        }

        footer {
            background-color: #FF3333;
            height: 50px;
            position: fixed;
            left: 0;
            bottom: 0;
            right: 0;
        }

        .page-break {
            page-break-after: always;
        }
        
        
    </style>
</head>

<body>
    <?php if(!$lastPage): ?>        
    <header>
        <div class="header_adp">
            <div class="title">
                <p style="color: #FF3333;"><strong>REPORTE DETALLADO POR CAMPAÑAS</strong></p>
            </div>
            <div class="logo">
            <?php if(!file_exists(storage_path('app/clientes/logo.png'))): ?>
                <img src="" width="100" alt="">
            <?php else: ?>
                <img src="../storage/app/clientes/logo.png" width="100" alt="">
            <?php endif; ?>
            </div>
        </div>
        <div class="header_cliente">
            <div class="cliente">
            <?php if(empty($cliente->logo)): ?>
                <img src="" width="100" alt="">
            <?php elseif(!file_exists(storage_path('app/clientes/').$cliente->alias."/".$cliente->logo)): ?>
                <img src="" width="100" alt="">
            <?php else: ?>
                <img src="../storage/app/clientes/<?php echo e($cliente->alias); ?>/<?php echo e($cliente->logo); ?>" style="max-height: 50px; max-width: 150px;" alt="">   
            <?php endif; ?>
            </div>
        </div>
    </header>
    <?php endif; ?>
    <main class="content">
    <?php if(!$lastPage): ?> 
        <?php $printPageBreak = true; ?>
        <?php if($printFirstPage): ?>
        <section class="first-page">
            <div class="container-table">
                <p><strong>Duración:</strong> del <?php echo e(date_format(date_create($fechaInicio), 'd-m-Y')); ?> al <?php echo e(date_format(date_create($fechaFin), 'd-m-Y')); ?></p>
                <p><strong>Publicaciones por campañas:</strong></p>
            </div>
            <?php if($isVal || $isDet): ?>
            <div class="container-table">
                <table class="summary-table">
                    <thead>
                        <tr>
                            <?php if($isDet): ?>
                            <th style="text-align: center;">Alcance Total</th>
                            <?php endif; ?>
                            <?php if($isVal): ?>
                            <th style="text-align: center;">Valorización Total</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <?php if($isDet): ?>
                            <td style="text-align: center;"><?php echo e(number_format($alcanceTotal)); ?></td>
                            <?php endif; ?>
                            <?php if($isVal): ?>
                            <td style="text-align: center;">S/. <?php echo e(number_format(($valorizadoTotal), 2, '.', ',')); ?></td>
                            <?php endif; ?>
                        </tr>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
            <div class="container-table">
                <table class="statistics-table">
                    <thead>
                        <tr>
                            <th style="text-align: center;">Campañas</th>
                            <?php $__currentLoopData = $tipoTiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoTier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php switch($tipoTier):
                            case (1): ?>
                                <th style="text-align: center;">Tier 1</th>
                                <?php break; ?>
                            <?php case (2): ?>
                                <th style="text-align: center;">Tier 2</th>
                                <?php break; ?>
                            <?php case (3): ?>
                                <th style="text-align: center;">Tier 3</th>
                                <?php break; ?>
                            <?php default: ?>
                                <th style="text-align: center;">-</th>
                                <?php break; ?>
                            <?php endswitch; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <th style="text-align: center;">TOTAL</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $campanasTotales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campanaTotal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="text-align: left;"><?php echo e($campanaTotal->titulo); ?></td>
                            <?php $__currentLoopData = $tipoTiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoTier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td style="text-align: center;"><?php echo e(($count[$campanaTotal->id][$tipoTier] > 0) ? $count[$campanaTotal->id][$tipoTier] : '-'); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td style="text-align: center; font-weight: bold;"><?php echo e(($count[$campanaTotal->id]['total'] > 0) ? $count[$campanaTotal->id]['total'] : '-'); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="text-align: center; font-weight: bold;">TOTAL</td>
                            <?php $__currentLoopData = $tipoTiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoTier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td style="text-align: center; font-weight: bold;"><?php echo e(($count['total'][$tipoTier] > 0) ? $count['total'][$tipoTier] : '-'); ?></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <td style="text-align: center; font-weight: bold;"><?php echo e(($count['total']['total'] > 0) ? $count['total']['total'] : '-'); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
        <?php else: ?>
        <?php $printPageBreak = false; ?>
        <?php endif; ?>
        <section class="second-page">
            <div class="container-table">
            <?php $__currentLoopData = $campanas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campana): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($printPageBreak): ?>
                <div class="page-break"></div>
                <?php endif; ?>
                <table>
                    <thead>
                        <tr>
                            <th style="text-align: left; text-transform: uppercase; font-weight: bold;" colspan="2"><?php echo e($campana->titulo); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $tipoTiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipoTier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($count[$campana->id][$tipoTier] > 0): ?>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($campana->id === $item->idCampaign  && $tipoTier === $item->tipoTier): ?>
                        <tr>
                            <td style="width: 50%;">
                                <ul style="list-style: none;">
                                <li>
                                <?php switch($item->tipoTier):
                                    case (1): ?>
                                        <div style="color: #FFFFFF; text-transform: uppercase; font-size: 10px; font-weight: bold; background-color: #02704B; margin: 10px 0px; height: 20px; line-height: 10px; width: 80px; text-align: center; border-radius: 2px;">Tier 1</div>
                                        <?php break; ?>
                                    <?php case (2): ?>
                                        <div style="color: #FFFFFF; text-transform: uppercase; font-size: 10px; font-weight: bold; background-color: #FE6D34; margin: 10px 0px; height: 20px; line-height: 10px; width: 80px; text-align: center; border-radius: 2px;">Tier 2</div>
                                        <?php break; ?>
                                    <?php case (3): ?>
                                        <div style="color: #FFFFFF; text-transform: uppercase; font-size: 10px; font-weight: bold; background-color: #FFD731; margin: 10px 0px; height: 20px; line-height: 10px; width: 80px; text-align: center; border-radius: 2px;">Tier 3</div>
                                        <?php break; ?>
                                    <?php default: ?>
                                        <div style="color: #FFFFFF; text-transform: uppercase; font-size: 10px; font-weight: bold; background-color: #FF3333; margin: 10px 0px; height: 20px; line-height: 10px; width: 80px; text-align: center; border-radius: 2px;">-</div>
                                        <?php break; ?>
                                <?php endswitch; ?>
                                </li>
                                    <li><strong>MEDIO:</strong> <?php echo e($item->Medio); ?></li>
                                    <?php if(!empty($item->Programa)): ?>
                                    <li><strong>PROGRAMA:</strong> <?php echo e($item->Programa); ?></li>
                                    <?php endif; ?>
                                    <?php if(isset($item->voceros) && !empty($item->voceros)): ?>
                                    <li><strong>VOCERO(S):</strong> <?php echo e($item->voceros); ?></li>
                                    <?php endif; ?>
                                    <li><strong>FECHA:</strong> <?php echo e(date_format(date_create($item->fechaPublicacion), 'd-m-Y')); ?></li>
                                    <?php if(!empty($item->url)): ?>
                                    <li><strong>LINK:</strong> <a href="<?php echo e($item->url); ?>"><?php echo e(implode(PHP_EOL, str_split($item->url, 40))); ?></a></li>
                                    <?php endif; ?>
                                    <?php if(!empty($item->Plataforma)): ?>
                                    <li><strong>PLATAFORMA:</strong> <?php echo e($item->Plataforma); ?></li>
                                    <?php endif; ?>
                                    <?php if($item->idPlataforma === 9): ?>
                                    <li><strong>RED:</strong> <?php echo e($item->Clasificacion); ?></li>
                                    <?php endif; ?>
                                    <?php if($item->idPlataforma === 5): ?>
                                    <li><strong>SECCIÓN:</strong> <?php echo e($item->MedioPlataforma); ?></li>
                                    <?php endif; ?>
                                    <?php if($isDet && $item->idPlataforma === 5): ?>
                                    <li><strong>CM<sup>2</sup>:</strong> <?php echo e(is_null($item->cm2) ? '0.00' : $item->cm2); ?></li>
                                    <?php endif; ?>
                                    <?php if($isDet && ($item->idPlataforma === 2 || $item->idPlataforma === 3)): ?>
                                    <li><strong>DURACIÓN:</strong> <?php echo e(is_null($item->segundos) ? '0' : $item->segundos); ?> segundos</li>
                                    <?php endif; ?>
                                    <?php if($isVal): ?>
                                    <li><strong>VALOR:</strong> S/. <?php echo e(number_format(($item->valorizado), 2, '.', ',')); ?></li>
                                    <?php endif; ?>
                                    <?php if($isDet && !empty($item->Alcance)): ?>
                                    <li><strong>ALCANCE:</strong> <?php echo e(number_format($item->Alcance)); ?></li>
                                    <?php endif; ?>
                                </ul>
                            </td>
                            <td style="width: 50%; text-align: center; padding: 15px">
                            <?php if(empty($item->foto)): ?>
                                <img src="../storage/app/clientes/reporte_img_default.jpg" width="250" alt="">
                            <?php elseif(!file_exists(storage_path('app/clientes/').$item->ruta_foto."/".$item->foto)): ?>
                                <img src="../storage/app/clientes/reporte_img_default.jpg" width="250" alt="">
                            <?php else: ?>
                                <a href="https://clippingclientes.pruebasgt.com/page/campaign/<?php echo e($item->idEncriptado); ?>"><img src="../storage/app/clientes/<?php echo e($item->ruta_foto); ?>/<?php echo e($item->foto); ?>" style="max-height: 250px; max-width: 250px;" alt=""></a>
                            <?php endif; ?>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php $printPageBreak = true; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </section>
    <?php endif; ?>
    <?php if($lastPage): ?> 
        <section class="third-page">
            <div style="margin-top: 350px; text-align: center;">
            <?php if(!file_exists(storage_path('app/clientes/logo.png'))): ?>
                <img src="" width="100" alt="">
            <?php else: ?>
                <img src="../storage/app/clientes/logo.png" width="100" alt="">
            <?php endif; ?>
                <p>REPORTE DETALLADO POR CAMPAÑAS</p>
            </div>
        </section>
    <?php endif; ?>    
    </main>
</body>

</html><?php /**PATH C:\laragon\www\server-agente-de-prensa\resources\views/pdf/reporte-campanas-tiers.blade.php ENDPATH**/ ?>